public class ClassForPlayerMarkerAndTurnCounter {
    String playerMarker;
    int turnCounter;

    public ClassForPlayerMarkerAndTurnCounter(String playerMarker, int turnCounter) {
        this.playerMarker = playerMarker;
        this.turnCounter = turnCounter;
    }

    public ClassForPlayerMarkerAndTurnCounter() {
        this.playerMarker = "";
        this.turnCounter = 0;
    }

}
