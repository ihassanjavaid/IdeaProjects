package Lab10;

import java.util.Scanner;
public class ATM {
    private Bucket fiveHundred;
    private Bucket thousand;
    private Bucket fiveThousand;

    public ATM() {
        fiveHundred = new Bucket();
        thousand = new Bucket();
        fiveThousand = new Bucket();

    }

    public int[] drawMoney(int amount) {
        //Declaration block
        int i = 0;
        int[] notes = new int[3];
        int tempAmount = amount;
        boolean loopFlag;

        //Initialization block
        if (isAmountValid(tempAmount)) {
            if (checkBalance() > tempAmount) {
                while (tempAmount > 0) {
                    loopFlag = false;
                    if (tempAmount > 10000 && fiveThousand.getNotes() > 0) {
                        while (tempAmount > 5000) {
                            tempAmount -= 5000;
                            fiveThousand.decreaseNotes();
                            notes[2]++;
                            loopFlag = true;
                        }
                    }
                    while (tempAmount > 1000 && thousand.getNotes() > 0) {
                        tempAmount -= 1000;
                        thousand.decreaseNotes();
                        notes[1]++;
                        loopFlag = true;
                    }
                    while (tempAmount >= 500 && fiveHundred.getNotes() > 0) {
                        tempAmount -= 500;
                        fiveHundred.decreaseNotes();
                        notes[0]++;
                        loopFlag = true;
                    }

                    //Fail safe
                    if (!loopFlag) {
                        System.out.println("Sorry the ATM has insufficient funds");
                        break;
                    }

                }
            } else {
                System.out.println("Sorry the ATM has insufficient funds");
            }
        } else {
            System.out.println("Amount is invalid, you are required to enter multiples of 500");
        }
        return notes;
    }

    private int checkBalance() {
        int balance = 0;

        balance = (fiveHundred.getNotes() * 500) + (thousand.getNotes() * 1000) + (fiveThousand.getNotes() * 5000);

        return balance;
    }

    private boolean isAmountValid(int amount) {
        if (amount % 500 == 0 && amount <= 25000)
            return true;
        else
            return false;
    }


    public class Bucket {
        private int notes;

        public Bucket() {
            notes = 10;

        }

        private int getNotes() {
            return notes;
        }

        public void decreaseNotes() {
            this.notes--;
        }

    }
}