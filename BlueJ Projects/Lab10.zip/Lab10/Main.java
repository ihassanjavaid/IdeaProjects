package Lab10;

public class Main
{

    public static void main(String[] args)
    {
        ATM HBL = new ATM();
        int [] notes;
        notes = HBL.drawMoney(10500);
        if (notes[0] > 0){
            System.out.println("500: " + notes[0] +"\n1000: " + notes[1] + "\n5000: " + notes[2]);
        }
        ATM Habib = new ATM();
        ATM.Bucket b1 = Habib.new Bucket();

        Display d = new Display();

    }

}
