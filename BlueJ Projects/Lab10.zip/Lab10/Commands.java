package Lab10;

import javax.swing.*;
import java.awt.*;

public class Commands extends JPanel{
    private JButton okButton;
    private JButton cancelButton;

    public Commands(){
        super();
        setBackground(Color.BLUE);
        okButton = new JButton("<html><i>O</i>k</html>");
        cancelButton = new JButton("<html><u>C</u>ancel</html>");
        this.add(okButton);
        this.add(cancelButton);
    }
}
